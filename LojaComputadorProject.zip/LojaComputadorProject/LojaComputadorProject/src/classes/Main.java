package classes;

public class Main {
    public static void main(String[] args) {
        LojaComputadores loja = new LojaComputadores();
        // Adicionar computadores à loja

        try {
            Computador computador = loja.buscarComputadorPorNome("Desktop Gamer");
            computador.descricaoDetalhada();
        } catch (ProdutoIndisponivelException e) {
            System.out.println("Erro ao buscar produto: " + e.getMessage());
        }
    }
}
