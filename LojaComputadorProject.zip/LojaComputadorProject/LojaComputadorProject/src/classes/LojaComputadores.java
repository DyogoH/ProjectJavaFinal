package classes;

import java.util.ArrayList;
import java.util.List;

public class LojaComputadores {
    private List<Computador> computadores;

    public LojaComputadores() {
        this.computadores = new ArrayList<>();
    }

    public void adicionarComputador(Computador computador) {
        computadores.add(computador);
    }

    public List<Computador> getComputadores() {
        return computadores;
    }

    public Computador buscarComputadorPorNome(String nome) throws ProdutoIndisponivelException {
        for (Computador computador : computadores) {
            if (computador.getNome().equalsIgnoreCase(nome)) {
                return computador;
            }
        }
        throw new ProdutoIndisponivelException("Produto não encontrado na loja: " + nome);
    }
}
