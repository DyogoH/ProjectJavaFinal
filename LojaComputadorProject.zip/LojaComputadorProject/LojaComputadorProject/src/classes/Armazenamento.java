/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

import interfaces.Descriavel;

/**
 *
 * @author dyogo
 */



public class Armazenamento extends ComponenteComputador implements Descriavel {
    public Armazenamento(int capacidadeGB, String tipo) {
        super(capacidadeGB, tipo);
    }

    @Override
    public String descricaoComponente() {
        return "Armazenamento: " + getCapacidadeGB() + "GB " + getTipo();
    }
}



